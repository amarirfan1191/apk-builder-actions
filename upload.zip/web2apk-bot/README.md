# Web2Apk Bot V2 Gen 1

Bot Telegram untuk build APK dari URL website atau fail ZIP projek Flutter/Android.

## Cara Setup

### 1. Install Node.js
- **Termux:** `pkg install nodejs`
- **VPS Ubuntu:** `apt install nodejs npm -y`
- **Panel Node.js:** Upload fail dan set entry point ke `index.js`

### 2. Install dependencies
```bash
npm install
```

### 3. Setup config
```bash
cp .env.example .env
nano .env   # edit dengan nilai kamu
```

Isi dalam `.env`:
- `BOT_TOKEN` — dari @BotFather
- `GITHUB_TOKEN` — dari github.com/settings/tokens/new (pilih: repo, workflow)
- `GITHUB_USERNAME` — username GitHub kamu

### 4. Jalankan bot
```bash
npm start
```

### Termux (background)
```bash
npm start &
# atau guna screen:
pkg install screen
screen -S bot
npm start
# Ctrl+A, D untuk detach
```

### VPS dengan PM2
```bash
npm install -g pm2
pm2 start index.js --name web2apk-bot
pm2 save
pm2 startup
```

## Admin Commands

| Command | Fungsi |
|---------|--------|
| `/adminhelp` | Semua admin commands |
| `/addpremium <id> [hari]` | Bagi akses premium |
| `/removepremium <id>` | Buang akses |
| `/listpremium` | Senarai premium |
| `/stats` | Statistik bot |
| `/setharga <harga>` | Set harga (contoh: RM10/bulan) |
| `/setnotel <no>` | Set no telefon untuk payment |
| `/setfoto` | Upload foto untuk menu /start |
| `/setqris` | Upload gambar QRIS payment |
| `/removefoto` | Buang foto /start |
| `/removeqris` | Buang QRIS |

## Cara Set QRIS / Foto

1. Buka bot dalam Telegram
2. Taip `/setqris`
3. Hantar gambar QRIS terus dalam chat
4. Done! QRIS akan muncul bila user cuba build tanpa premium.

## Cara Aktifkan User Premium

1. Minta user hantar ID (@userinfobot untuk tahu ID)
2. Taip: `/addpremium 123456789 30` (30 = hari)
3. User terus dapat notifikasi akses aktif

## User Commands

- `/start` — Menu utama
- Pilih **Perintah** → **Build dari URL** atau **Build dari ZIP**

## Requirements

- Node.js 18+
- GitHub account dengan repo + GitHub Actions enabled
- Telegram bot token dari @BotFather
