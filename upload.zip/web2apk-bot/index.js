require("dotenv").config();
const TelegramBot = require("node-telegram-bot-api");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { execSync } = require("child_process");

// ─── CONFIG (edit .env atau terus kat sini) ───────────────────────────────────

const BOT_TOKEN = process.env.BOT_TOKEN || "";
const GITHUB_TOKEN = process.env.GITHUB_TOKEN || "";
const GITHUB_USERNAME = process.env.GITHUB_USERNAME || "";
const GITHUB_REPO = process.env.GITHUB_REPO || "apk-builder-actions";
const OWNER_USERNAME = process.env.OWNER_USERNAME || "KingIpanzzx";
const BOT_NAME = process.env.BOT_NAME || "Web2Apk";
const BOT_VERSION = process.env.BOT_VERSION || "V2 Gen 1";

// ─── DATA ─────────────────────────────────────────────────────────────────────

const DATA_FILE = path.join(__dirname, "data.json");
const ASSETS_DIR = path.join(__dirname, "assets");
if (!fs.existsSync(ASSETS_DIR)) fs.mkdirSync(ASSETS_DIR, { recursive: true });

function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {}
  return {
    premiumUsers: {},
    stats: { success: 0, failed: 0 },
    buildLog: [],
    config: {
      startPhotoPath: null,
      qrisPhotoPath: null,
      harga: "RM10 / bulan",
      notel: null,
    },
  };
}

function saveData(d) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2));
}

let data = loadData();
if (!data.config) data.config = { startPhotoPath: null, qrisPhotoPath: null, harga: "RM10 / bulan", notel: null };

// ─── STATE ────────────────────────────────────────────────────────────────────

const activeBuilds = {};
const userState = {};
const TOTAL_SLOTS = 4;

let bot = null;

// ─── GITHUB ───────────────────────────────────────────────────────────────────

const ghHeaders = {
  Authorization: `token ${GITHUB_TOKEN}`,
  Accept: "application/vnd.github.v3+json",
};

async function ensureGithubRepo() {
  try {
    await axios.get(`https://api.github.com/repos/${GITHUB_USERNAME}/${GITHUB_REPO}`, { headers: ghHeaders });
    console.log("✅ GitHub repo exists");
  } catch {
    console.log("📦 Creating GitHub repo...");
    await axios.post(
      "https://api.github.com/user/repos",
      { name: GITHUB_REPO, private: false, auto_init: true, description: "APK Builder via Bot" },
      { headers: ghHeaders }
    );
    await new Promise((r) => setTimeout(r, 4000));
  }
  await pushWorkflowFile();
}

async function getFileSha(fp) {
  try {
    const r = await axios.get(
      `https://api.github.com/repos/${GITHUB_USERNAME}/${GITHUB_REPO}/contents/${fp}`,
      { headers: ghHeaders }
    );
    return r.data.sha;
  } catch { return undefined; }
}

async function pushFile(fp, content, msg) {
  const encoded = Buffer.from(content).toString("base64");
  const sha = await getFileSha(fp);
  const body = { message: msg, content: encoded };
  if (sha) body.sha = sha;
  await axios.put(
    `https://api.github.com/repos/${GITHUB_USERNAME}/${GITHUB_REPO}/contents/${fp}`,
    body,
    { headers: ghHeaders }
  );
}

async function pushBinaryFile(fp, buffer, msg) {
  const encoded = buffer.toString("base64");
  const sha = await getFileSha(fp);
  const body = { message: msg, content: encoded };
  if (sha) body.sha = sha;
  await axios.put(
    `https://api.github.com/repos/${GITHUB_USERNAME}/${GITHUB_REPO}/contents/${fp}`,
    body,
    { headers: ghHeaders }
  );
}

async function pushWorkflowFile() {
  const workflow = `name: Build APK
on:
  workflow_dispatch:
    inputs:
      build_type:
        description: 'url or zip'
        required: true
        default: 'url'
      url:
        description: 'Website URL'
        required: false
      app_name:
        description: 'App Name'
        required: true

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Java 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Accept licenses & install tools
        run: |
          yes | sdkmanager --licenses || true
          sdkmanager "build-tools;34.0.0" "platforms;android-34" || true

      - name: Create WebView project
        if: github.event.inputs.build_type == 'url'
        run: |
          APP_URL="\${{ github.event.inputs.url }}"
          APP_NAME="\${{ github.event.inputs.app_name }}"
          PKG="com.apkbot.\$(echo "\${APP_NAME}" | tr '[:upper:]' '[:lower:]' | tr -cd 'a-z0-9' | head -c20)"
          mkdir -p webview-app/app/src/main/java/com/apkbot/app
          mkdir -p webview-app/app/src/main/res/{layout,values}
          mkdir -p webview-app/gradle/wrapper

          cat > webview-app/settings.gradle << 'EOF'
rootProject.name = "WebViewApp"
include ':app'
EOF
          cat > webview-app/build.gradle << 'EOF'
buildscript {
    repositories { google(); mavenCentral() }
    dependencies { classpath 'com.android.tools.build:gradle:8.2.2' }
}
allprojects { repositories { google(); mavenCentral() } }
EOF
          cat > webview-app/gradle.properties << 'EOF'
android.useAndroidX=true
org.gradle.daemon=false
EOF
          cat > webview-app/gradle/wrapper/gradle-wrapper.properties << 'EOF'
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip
EOF
          cat > webview-app/app/build.gradle << EOF
plugins { id 'com.android.application' }
android {
  namespace "\${PKG}"
  compileSdk 34
  defaultConfig {
    applicationId "\${PKG}"
    minSdk 21; targetSdk 34
    versionCode 1; versionName "1.0"
  }
  buildTypes { release { minifyEnabled false; signingConfig signingConfigs.debug } }
  compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }
}
dependencies { implementation 'androidx.appcompat:appcompat:1.6.1' }
EOF
          cat > webview-app/app/src/main/AndroidManifest.xml << EOF
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
  <uses-permission android:name="android.permission.INTERNET"/>
  <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
  <application android:allowBackup="true" android:label="\${APP_NAME}" android:usesCleartextTraffic="true" android:theme="@style/Theme.AppCompat.NoActionBar">
    <activity android:name=".MainActivity" android:exported="true" android:configChanges="orientation|screenSize">
      <intent-filter>
        <action android:name="android.intent.action.MAIN"/>
        <category android:name="android.intent.category.LAUNCHER"/>
      </intent-filter>
    </activity>
  </application>
</manifest>
EOF
          cat > webview-app/app/src/main/java/com/apkbot/app/MainActivity.java << EOF
package com.apkbot.app;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
public class MainActivity extends Activity {
  private WebView wv;
  @SuppressLint("SetJavaScriptEnabled")
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    wv = new WebView(this);
    WebSettings s = wv.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setLoadWithOverviewMode(true); s.setUseWideViewPort(true);
    wv.setWebViewClient(new WebViewClient());
    wv.loadUrl("\${APP_URL}");
    setContentView(wv);
  }
  @Override public void onBackPressed() { if (wv.canGoBack()) wv.goBack(); else super.onBackPressed(); }
}
EOF
          cat > webview-app/app/src/main/res/values/strings.xml << EOF
<?xml version="1.0" encoding="utf-8"?>
<resources><string name="app_name">\${APP_NAME}</string></resources>
EOF

      - name: Build URL APK
        if: github.event.inputs.build_type == 'url'
        working-directory: webview-app
        run: |
          gradle wrapper && chmod +x gradlew
          ./gradlew assembleRelease --no-daemon 2>&1 | tail -50
          find . -name "*.apk" -exec cp {} ../output.apk \\;

      - name: Extract ZIP
        if: github.event.inputs.build_type == 'zip'
        run: |
          [ -f "upload.zip" ] || (echo "upload.zip missing!" && exit 1)
          unzip -o upload.zip -d zip-project

      - name: Build ZIP project
        if: github.event.inputs.build_type == 'zip'
        run: |
          FLUTTER_DIR=\$(find zip-project -name "pubspec.yaml" | head -1 | xargs dirname 2>/dev/null || echo "")
          GRADLE_DIR=\$(find zip-project -name "gradlew" | head -1 | xargs dirname 2>/dev/null || echo "")
          if [ -n "\$FLUTTER_DIR" ]; then
            echo "Flutter: \$FLUTTER_DIR"
            sudo snap install flutter --classic 2>/dev/null || true
            export PATH="\$HOME/snap/flutter/common/flutter/bin:\$PATH"
            cd "\$FLUTTER_DIR"
            flutter pub get && flutter build apk --release --no-tree-shake-icons
            find . -name "*.apk" | head -1 | xargs -I{} cp {} \$GITHUB_WORKSPACE/output.apk
          elif [ -n "\$GRADLE_DIR" ]; then
            echo "Gradle: \$GRADLE_DIR"
            cd "\$GRADLE_DIR" && chmod +x gradlew
            ./gradlew assembleRelease --no-daemon 2>&1 | tail -50
            find . -name "*.apk" | head -1 | xargs -I{} cp {} \$GITHUB_WORKSPACE/output.apk
          else
            echo "Unknown project!" && exit 1
          fi

      - name: Verify & Upload APK
        run: |
          ls -lh output.apk || (echo "No APK produced!" && exit 1)

      - name: Upload artifact
        uses: actions/upload-artifact@v4
        with:
          name: apk-output
          path: output.apk
          retention-days: 1
`;
  await pushFile(".github/workflows/build-apk.yml", workflow, "Update workflow");
  console.log("✅ Workflow pushed to GitHub");
}

// ─── TRIGGER & POLL ───────────────────────────────────────────────────────────

async function triggerWorkflow(inputs) {
  const before = Date.now();
  await axios.post(
    `https://api.github.com/repos/${GITHUB_USERNAME}/${GITHUB_REPO}/actions/workflows/build-apk.yml/dispatches`,
    { ref: "main", inputs },
    { headers: ghHeaders }
  );
  await new Promise((r) => setTimeout(r, 7000));
  const runsRes = await axios.get(
    `https://api.github.com/repos/${GITHUB_USERNAME}/${GITHUB_REPO}/actions/runs?per_page=5`,
    { headers: ghHeaders }
  );
  const run = runsRes.data.workflow_runs.find(
    (r) => new Date(r.created_at).getTime() >= before - 15000
  );
  return run?.id ?? null;
}

async function pollUntilDone(runId, timeoutMs = 15 * 60 * 1000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    await new Promise((r) => setTimeout(r, 20000));
    try {
      const res = await axios.get(
        `https://api.github.com/repos/${GITHUB_USERNAME}/${GITHUB_REPO}/actions/runs/${runId}`,
        { headers: ghHeaders }
      );
      const { status, conclusion } = res.data;
      console.log(`⏳ Run ${runId}: ${status} / ${conclusion}`);
      if (status === "completed") return conclusion === "success" ? "success" : "failure";
    } catch {}
  }
  return "timeout";
}

async function downloadApk(runId) {
  const artsRes = await axios.get(
    `https://api.github.com/repos/${GITHUB_USERNAME}/${GITHUB_REPO}/actions/runs/${runId}/artifacts`,
    { headers: ghHeaders }
  );
  const artifact = artsRes.data.artifacts?.[0];
  if (!artifact) return null;
  const dlRes = await axios.get(
    `https://api.github.com/repos/${GITHUB_USERNAME}/${GITHUB_REPO}/actions/artifacts/${artifact.id}/zip`,
    { headers: { ...ghHeaders }, responseType: "arraybuffer", maxRedirects: 5 }
  );
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "apk-"));
  const zipPath = path.join(tmpDir, "apk.zip");
  fs.writeFileSync(zipPath, dlRes.data);
  execSync(`unzip -o "${zipPath}" -d "${tmpDir}"`);
  const files = fs.readdirSync(tmpDir).filter((f) => f.endsWith(".apk"));
  if (!files.length) return null;
  return path.join(tmpDir, files[0]);
}

// ─── KEYBOARDS ────────────────────────────────────────────────────────────────

const mainMenuKeyboard = {
  inline_keyboard: [
    [
      { text: "ℹ️ Bantuan", callback_data: "bantuan" },
      { text: "📊 Status Build", callback_data: "status" },
    ],
    [{ text: "🚀 Perintah", callback_data: "perintah" }],
    [
      { text: "👤 Owner", url: `https://t.me/${OWNER_USERNAME}` },
      { text: "ℹ️ Information", callback_data: "info" },
    ],
  ],
};

const buildMenuKeyboard = {
  inline_keyboard: [
    [
      { text: "📁 Build dari ZIP", callback_data: "build_zip" },
      { text: "🌐 Build dari URL", callback_data: "build_url" },
    ],
    [{ text: "🔙 Kembali", callback_data: "main_menu" }],
  ],
};

const backKeyboard = {
  inline_keyboard: [[{ text: "🔙 Kembali", callback_data: "main_menu" }]],
};

// ─── MENU FUNCTIONS ───────────────────────────────────────────────────────────

async function sendMainMenu(chatId, editMsgId) {
  const text =
    `🤖 *${BOT_NAME} ${BOT_VERSION}*\n\n` +
    `Bangun APK dari projek Flutter/Android dengan alur yang rapi, cepat, dan terukur.\n\n` +
    `*Fitur utama*\n` +
    `• GitHub Actions worker\n` +
    `• Build dari ZIP atau URL\n` +
    `• APK dihantar terus dalam chat\n\n` +
    `Silakan pilih menu:`;

  const opts = { parse_mode: "Markdown", reply_markup: mainMenuKeyboard };

  if (editMsgId) {
    try {
      await bot.editMessageText(text, { chat_id: chatId, message_id: editMsgId, ...opts });
      return;
    } catch {}
  }

  // Kalau ada foto /start
  const photo = data.config.startPhotoPath;
  if (photo && fs.existsSync(photo)) {
    await bot.sendPhoto(chatId, photo, { caption: text, parse_mode: "Markdown", reply_markup: mainMenuKeyboard });
  } else {
    await bot.sendMessage(chatId, text, opts);
  }
}

async function sendStatusMsg(chatId, editMsgId) {
  const activeList = Object.values(activeBuilds);
  const slotsUsed = activeList.length;
  const elapsed = (job) => {
    const sec = Math.floor((Date.now() - job.startedAt) / 1000);
    return `${Math.floor(sec / 60)}m ${sec % 60}s`;
  };

  let workerLines = "";
  for (let i = 1; i <= TOTAL_SLOTS; i++) {
    const job = activeList[i - 1];
    if (job) {
      workerLines += `🟡 worker-${i} — Sedang Build\n`;
      workerLines += `  └ 👤 @${job.username || "user"} (${elapsed(job)}) / est ~5m\n`;
    } else {
      workerLines += `🟢 worker-${i} — Siap\n`;
      workerLines += `  └ ✅ Tersedia untuk build\n`;
    }
  }

  const text =
    `📊 *Status Antrian Build*\n\n` +
    `🖥️ Server: Aktif\n` +
    `📶 Slot: ${slotsUsed}/${TOTAL_SLOTS}\n\n` +
    `⚙️ *Worker GitHub Actions (${TOTAL_SLOTS}):*\n` +
    workerLines + `\n` +
    `📈 *Statistik:*\n` +
    `✅ ${data.stats.success} berjaya | ❌ ${data.stats.failed} gagal | ⏱ ~5m\n\n` +
    `💡 Klik tombol di bawah untuk mulai build!`;

  const keyboard = {
    inline_keyboard: [
      [{ text: "🔄 Refresh", callback_data: "status" }, { text: "🔙 Kembali", callback_data: "main_menu" }],
    ],
  };

  const opts = { parse_mode: "Markdown", reply_markup: keyboard };
  if (editMsgId) {
    try { await bot.editMessageText(text, { chat_id: chatId, message_id: editMsgId, ...opts }); return; } catch {}
  }
  await bot.sendMessage(chatId, text, opts);
}

// ─── PREMIUM CHECK ────────────────────────────────────────────────────────────

function isPremium(chatId) {
  const u = data.premiumUsers[chatId];
  if (!u) return false;
  if (u.expiry && new Date(u.expiry) < new Date()) {
    delete data.premiumUsers[chatId];
    saveData(data);
    return false;
  }
  return true;
}

async function sendPremiumNag(chatId) {
  const qris = data.config.qrisPhotoPath;
  const harga = data.config.harga || "RM10 / bulan";
  const notel = data.config.notel ? `📱 ${data.config.notel}\n` : "";

  const caption =
    `🔒 *Akses Premium Diperlukan*\n\n` +
    `Fitur build APK adalah untuk pengguna premium sahaja.\n\n` +
    `💰 *Harga:* ${harga}\n` +
    notel +
    `👤 *Owner:* @${OWNER_USERNAME}\n\n` +
    `_Setelah bayar, hantar bukti kepada owner untuk aktifkan akses._`;

  const keyboard = {
    inline_keyboard: [
      [{ text: `💬 Hubungi @${OWNER_USERNAME}`, url: `https://t.me/${OWNER_USERNAME}` }],
      [{ text: "🔙 Kembali", callback_data: "main_menu" }],
    ],
  };

  if (qris && fs.existsSync(qris)) {
    await bot.sendPhoto(chatId, qris, { caption, parse_mode: "Markdown", reply_markup: keyboard });
  } else {
    await bot.sendMessage(chatId, caption, { parse_mode: "Markdown", reply_markup: keyboard });
  }
}

// ─── BUILD ────────────────────────────────────────────────────────────────────

async function runBuild(chatId, username, inputs, label) {
  const startedAt = Date.now();
  activeBuilds[chatId] = { chatId, username, appName: label, startedAt };

  await bot.sendMessage(chatId,
    `⚙️ *Build Dimulakan*\n\n📱 App: *${label}*\n🔧 Jenis: ${inputs.build_type === "url" ? "🌐 URL" : "📁 ZIP"}\n\nSila tunggu ~5-10 minit...`,
    { parse_mode: "Markdown" }
  );

  let runId;
  try {
    runId = await triggerWorkflow(inputs);
  } catch (e) {
    console.error("triggerWorkflow error:", e.message);
  }

  if (!runId) {
    delete activeBuilds[chatId];
    data.stats.failed++;
    saveData(data);
    await bot.sendMessage(chatId, "❌ Gagal mulakan build di GitHub Actions. Cuba semula /start");
    return;
  }

  await bot.sendMessage(chatId, "🔄 Build berjalan... Bot akan hantar APK bila siap!");

  const result = await pollUntilDone(runId);
  const duration = Math.floor((Date.now() - startedAt) / 1000);
  delete activeBuilds[chatId];

  if (result === "timeout") {
    data.stats.failed++; saveData(data);
    await bot.sendMessage(chatId, "⏰ Build tamat masa. Cuba /start semula.");
    return;
  }
  if (result === "failure") {
    data.stats.failed++; saveData(data);
    await bot.sendMessage(chatId,
      `❌ *Build Gagal*\n\nKemungkinan sebab:\n• Error dalam kod projek\n• Dependency tidak lengkap\n• URL tidak boleh diakses\n\nHubungi @${OWNER_USERNAME} untuk bantuan.`,
      { parse_mode: "Markdown" }
    );
    return;
  }

  let apkPath;
  try { apkPath = await downloadApk(runId); } catch (e) { console.error("downloadApk:", e.message); }

  if (!apkPath) {
    data.stats.failed++; saveData(data);
    await bot.sendMessage(chatId, "⚠️ APK tidak dijumpai. Cuba /start semula.");
    return;
  }

  data.stats.success++;
  data.buildLog.push({ chatId, username, appName: label, status: "success", duration, at: new Date().toISOString() });
  if (data.buildLog.length > 100) data.buildLog = data.buildLog.slice(-100);
  saveData(data);

  await bot.sendDocument(chatId, apkPath, {
    caption:
      `✅ *Build Berjaya!*\n\n📱 *${label}*\n⏱ Masa: ${Math.floor(duration / 60)}m ${duration % 60}s\n\n` +
      `*Cara install:*\n1. Download APK\n2. Settings → Install unknown apps → Allow\n3. Tap APK\n\n_Built by @${OWNER_USERNAME}_`,
    parse_mode: "Markdown",
  }, { filename: `${label.replace(/\s+/g, "_")}.apk`, contentType: "application/vnd.android.package-archive" });

  try { fs.unlinkSync(apkPath); } catch {}
  userState[chatId] = { step: "idle" };
}

// ─── BOT START ────────────────────────────────────────────────────────────────

async function startBot() {
  if (!BOT_TOKEN) { console.error("❌ BOT_TOKEN tidak diset dalam .env!"); process.exit(1); }
  if (!GITHUB_TOKEN) { console.error("❌ GITHUB_TOKEN tidak diset dalam .env!"); process.exit(1); }
  if (!GITHUB_USERNAME) { console.error("❌ GITHUB_USERNAME tidak diset dalam .env!"); process.exit(1); }

  bot = new TelegramBot(BOT_TOKEN, { polling: true });
  console.log(`✅ ${BOT_NAME} ${BOT_VERSION} Bot started!`);
  console.log(`👤 Owner: @${OWNER_USERNAME}`);

  try { await ensureGithubRepo(); } catch (e) { console.error("GitHub setup error:", e.message); }

  // /start
  bot.onText(/\/start/, (msg) => {
    userState[msg.chat.id] = { step: "idle" };
    sendMainMenu(msg.chat.id);
  });

  // ─── ADMIN COMMANDS ─────────────────────────────────────────────────────────

  // /addpremium <id> [hari]
  bot.onText(/\/addpremium (.+)/, async (msg, match) => {
    if (msg.from?.username !== OWNER_USERNAME) return;
    const parts = match[1].trim().split(" ");
    const uid = parseInt(parts[0]);
    const days = parts[1] ? parseInt(parts[1]) : null;
    if (isNaN(uid)) { bot.sendMessage(msg.chat.id, "❌ Contoh: /addpremium 123456 30"); return; }
    const expiry = days ? new Date(Date.now() + days * 86400000).toISOString() : null;
    data.premiumUsers[uid] = { addedAt: new Date().toISOString(), expiry };
    saveData(data);
    const expiryTxt = expiry ? `\nTamat: ${new Date(expiry).toLocaleDateString("ms-MY")}` : "\n(Tanpa tamat)";
    bot.sendMessage(msg.chat.id, `✅ User ${uid} dapat akses premium!${expiryTxt}`);
    bot.sendMessage(uid, `🎉 Akses premium kamu telah diaktifkan oleh @${OWNER_USERNAME}!\n\nGuna /start untuk mula build APK.`).catch(() => {});
  });

  // /removepremium <id>
  bot.onText(/\/removepremium (.+)/, (msg, match) => {
    if (msg.from?.username !== OWNER_USERNAME) return;
    const uid = parseInt(match[1]);
    delete data.premiumUsers[uid];
    saveData(data);
    bot.sendMessage(msg.chat.id, `✅ Akses premium user ${uid} dibuang.`);
  });

  // /listpremium
  bot.onText(/\/listpremium/, (msg) => {
    if (msg.from?.username !== OWNER_USERNAME) return;
    const list = Object.entries(data.premiumUsers);
    if (!list.length) { bot.sendMessage(msg.chat.id, "Tiada pengguna premium."); return; }
    const txt = list.map(([id, u]) => `• ${id}${u.expiry ? ` (tamat: ${u.expiry.slice(0, 10)})` : ""}`).join("\n");
    bot.sendMessage(msg.chat.id, `👥 *Premium Users (${list.length}):*\n${txt}`, { parse_mode: "Markdown" });
  });

  // /stats
  bot.onText(/\/stats/, (msg) => {
    if (msg.from?.username !== OWNER_USERNAME) return;
    bot.sendMessage(msg.chat.id,
      `📊 *Bot Stats*\n✅ Berjaya: ${data.stats.success}\n❌ Gagal: ${data.stats.failed}\n👥 Premium: ${Object.keys(data.premiumUsers).length}\n🔧 Active: ${Object.keys(activeBuilds).length}`,
      { parse_mode: "Markdown" }
    );
  });

  // /setharga <harga>
  bot.onText(/\/setharga (.+)/, (msg, match) => {
    if (msg.from?.username !== OWNER_USERNAME) return;
    data.config.harga = match[1].trim();
    saveData(data);
    bot.sendMessage(msg.chat.id, `✅ Harga ditetapkan: ${data.config.harga}`);
  });

  // /setnotel <no>
  bot.onText(/\/setnotel (.+)/, (msg, match) => {
    if (msg.from?.username !== OWNER_USERNAME) return;
    data.config.notel = match[1].trim();
    saveData(data);
    bot.sendMessage(msg.chat.id, `✅ No Tel: ${data.config.notel}`);
  });

  // /setfoto — hantar foto lepas command ini
  bot.onText(/\/setfoto/, (msg) => {
    if (msg.from?.username !== OWNER_USERNAME) return;
    userState[msg.chat.id] = { step: "admin_set_startfoto" };
    bot.sendMessage(msg.chat.id, "📸 Hantar foto untuk menu /start:");
  });

  // /setqris — hantar gambar QRIS lepas command ini
  bot.onText(/\/setqris/, (msg) => {
    if (msg.from?.username !== OWNER_USERNAME) return;
    userState[msg.chat.id] = { step: "admin_set_qris" };
    bot.sendMessage(msg.chat.id, "💳 Hantar gambar QRIS kamu:");
  });

  // /removefoto
  bot.onText(/\/removefoto/, (msg) => {
    if (msg.from?.username !== OWNER_USERNAME) return;
    data.config.startPhotoPath = null;
    saveData(data);
    bot.sendMessage(msg.chat.id, "✅ Foto /start dibuang.");
  });

  // /removeqris
  bot.onText(/\/removeqris/, (msg) => {
    if (msg.from?.username !== OWNER_USERNAME) return;
    data.config.qrisPhotoPath = null;
    saveData(data);
    bot.sendMessage(msg.chat.id, "✅ QRIS dibuang.");
  });

  // /adminhelp
  bot.onText(/\/adminhelp/, (msg) => {
    if (msg.from?.username !== OWNER_USERNAME) return;
    bot.sendMessage(msg.chat.id,
      `🔧 *Admin Commands:*\n\n` +
      `/addpremium <id> [hari] — Bagi premium\n` +
      `/removepremium <id> — Buang premium\n` +
      `/listpremium — Senarai premium\n` +
      `/stats — Statistik bot\n` +
      `/setharga <harga> — Set harga premium\n` +
      `/setnotel <no> — Set no telefon\n` +
      `/setfoto — Set foto utama /start\n` +
      `/setqris — Set gambar QRIS payment\n` +
      `/removefoto — Buang foto\n` +
      `/removeqris — Buang QRIS`,
      { parse_mode: "Markdown" }
    );
  });

  // ─── CALLBACK QUERIES ────────────────────────────────────────────────────────

  bot.on("callback_query", async (query) => {
    const chatId = query.message.chat.id;
    const msgId = query.message.message_id;
    const cb = query.data;
    const username = query.from.username;

    await bot.answerCallbackQuery(query.id).catch(() => {});

    if (cb === "main_menu") {
      userState[chatId] = { step: "idle" };
      await sendMainMenu(chatId, msgId);
    } else if (cb === "bantuan") {
      await bot.editMessageText(
        `ℹ️ *Bantuan ${BOT_NAME} ${BOT_VERSION}*\n\n` +
        `*Build dari URL:*\nPilih Perintah → Build dari URL → masukkan URL website\n\n` +
        `*Build dari ZIP:*\nPilih Perintah → Build dari ZIP → hantar fail .zip projek Flutter/Android\n\n` +
        `*Masa build:* ~5-10 minit\n\n` +
        `*Sokongan:* @${OWNER_USERNAME}`,
        { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: backKeyboard }
      ).catch(() => bot.sendMessage(chatId, "ℹ️ Pilih Perintah untuk mula build.", { reply_markup: backKeyboard }));
    } else if (cb === "status") {
      await sendStatusMsg(chatId, msgId);
    } else if (cb === "perintah") {
      await bot.editMessageText(
        `🚀 *Pilih Jenis Build*\n\nSilakan pilih mode build:`,
        { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: buildMenuKeyboard }
      ).catch(() => bot.sendMessage(chatId, "Pilih jenis build:", { reply_markup: buildMenuKeyboard }));
    } else if (cb === "info") {
      await bot.editMessageText(
        `ℹ️ *Maklumat Bot*\n\n` +
        `🤖 Nama: ${BOT_NAME} ${BOT_VERSION}\n` +
        `👤 Developer: @${OWNER_USERNAME}\n` +
        `⚙️ Engine: GitHub Actions\n` +
        `📦 Support: Flutter & Android Studio\n` +
        `🔒 Sistem: Premium\n\n` +
        `_Build APK tanpa limit, cepat dan selamat!_`,
        { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: backKeyboard }
      ).catch(() => {});
    } else if (cb === "build_url") {
      if (!isPremium(chatId)) { await sendPremiumNag(chatId); return; }
      if (activeBuilds[chatId]) { bot.sendMessage(chatId, "⚠️ Kamu ada build yang sedang berjalan. Tunggu ia siap!"); return; }
      userState[chatId] = { step: "waiting_url", buildType: "url" };
      bot.sendMessage(chatId, "🌐 *Masukkan URL website:*\n\nContoh: https://example.com", { parse_mode: "Markdown" });
    } else if (cb === "build_zip") {
      if (!isPremium(chatId)) { await sendPremiumNag(chatId); return; }
      if (activeBuilds[chatId]) { bot.sendMessage(chatId, "⚠️ Kamu ada build yang sedang berjalan. Tunggu ia siap!"); return; }
      userState[chatId] = { step: "waiting_zip", buildType: "zip" };
      bot.sendMessage(chatId, "📦 *Hantar fail .zip projek Flutter/Android kamu:*", { parse_mode: "Markdown" });
    }
  });

  // ─── PHOTO HANDLER ───────────────────────────────────────────────────────────

  bot.on("photo", async (msg) => {
    const chatId = msg.chat.id;
    const state = userState[chatId];
    if (!state) return;

    if (state.step === "admin_set_startfoto" || state.step === "admin_set_qris") {
      const photo = msg.photo[msg.photo.length - 1];
      const fileLink = await bot.getFileLink(photo.file_id);
      const dlRes = await axios.get(fileLink, { responseType: "arraybuffer" });
      const key = state.step === "admin_set_startfoto" ? "startPhotoPath" : "qrisPhotoPath";
      const fname = state.step === "admin_set_startfoto" ? "start-photo.jpg" : "qris.jpg";
      const savePath = path.join(ASSETS_DIR, fname);
      fs.writeFileSync(savePath, dlRes.data);
      data.config[key] = savePath;
      saveData(data);
      userState[chatId] = { step: "idle" };
      bot.sendMessage(chatId, `✅ ${state.step === "admin_set_startfoto" ? "Foto /start" : "QRIS"} berjaya disimpan!`);
    }
  });

  // ─── DOCUMENT HANDLER (ZIP) ──────────────────────────────────────────────────

  bot.on("document", async (msg) => {
    const chatId = msg.chat.id;
    const state = userState[chatId];
    if (!state || state.step !== "waiting_zip") return;

    const doc = msg.document;
    if (!doc.file_name?.endsWith(".zip")) { bot.sendMessage(chatId, "❌ Fail mesti .zip."); return; }
    if (doc.file_size > 50 * 1024 * 1024) { bot.sendMessage(chatId, "❌ Fail terlalu besar (max 50MB)."); return; }

    bot.sendMessage(chatId, "⬇️ Download fail ZIP...");
    try {
      const fileLink = await bot.getFileLink(doc.file_id);
      const dlRes = await axios.get(fileLink, { responseType: "arraybuffer" });
      bot.sendMessage(chatId, "⬆️ Upload ke GitHub...");
      await pushBinaryFile("upload.zip", Buffer.from(dlRes.data), "Upload user zip");
      userState[chatId] = { step: "waiting_name_zip", buildType: "zip" };
      bot.sendMessage(chatId, "✅ ZIP berjaya!\n\n📱 *Nama app kamu:*", { parse_mode: "Markdown" });
    } catch (e) {
      console.error("ZIP upload:", e.message);
      bot.sendMessage(chatId, "❌ Gagal upload ZIP. Cuba /start semula.");
      userState[chatId] = { step: "idle" };
    }
  });

  // ─── TEXT HANDLER ────────────────────────────────────────────────────────────

  bot.on("message", async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text?.trim();
    if (!text || text.startsWith("/")) return;
    const state = userState[chatId];
    if (!state) return;

    if (state.step === "waiting_url") {
      const url = text.startsWith("http") ? text : `https://${text}`;
      try { new URL(url); } catch { bot.sendMessage(chatId, "❌ URL tidak sah. Contoh: https://example.com"); return; }
      userState[chatId] = { ...state, step: "waiting_name", url };
      bot.sendMessage(chatId, "📱 *Nama app kamu:*", { parse_mode: "Markdown" });
      return;
    }

    if (state.step === "waiting_name" && state.buildType === "url") {
      userState[chatId] = { step: "building" };
      runBuild(chatId, msg.from?.username, { build_type: "url", url: state.url, app_name: text }, text).catch((e) => {
        console.error("runBuild:", e.message);
        bot.sendMessage(chatId, "❌ Ralat tidak dijangka. Cuba /start semula.");
        userState[chatId] = { step: "idle" };
      });
      return;
    }

    if (state.step === "waiting_name_zip") {
      userState[chatId] = { step: "building" };
      runBuild(chatId, msg.from?.username, { build_type: "zip", app_name: text }, text).catch((e) => {
        console.error("runBuild:", e.message);
        bot.sendMessage(chatId, "❌ Ralat tidak dijangka. Cuba /start semula.");
        userState[chatId] = { step: "idle" };
      });
    }
  });

  bot.on("polling_error", (err) => console.error("Polling error:", err.message));

  console.log("🤖 Bot siap! Taip /start dalam Telegram.");
}

startBot().catch(console.error);
