module.exports = {
  TOKEN: process.env.TELEGRAM_TOKEN || "8632274154:AAHxGrgtjaqIPtHSdcFAuKKOvw3XongxlzU",
  OWNER_ID: process.env.OWNER_ID || 8472251509,
  ID_GROUP: [
    -1002933860223
  ],
  ID_GROUP_UTAMA: [
    -1002933860223
  ]
};