module.exports = {
      PORT: process.env.PORT || 2002,
  WS_PORT: process.env.WS_PORT || 2002,
  BUGS: [
    { bug_id: "freeze", bug_name: "Freeze Invisible" },
    { bug_id: "delays", bug_name: "Ultra Force Close" },
    { bug_id: "blank", bug_name: "Blank Device" },
    { bug_id: "ios", bug_name: "Crash Invisible iPhone" },
    { bug_id: "infinity", bug_name: "Blank Android 7-16" }
  ],
    
  payload: [
   { bug_id: "freeze", bug_name: "Freeze Invisible" },
    { bug_id: "delays", bug_name: "Ultra Force Close" },
    { bug_id: "blank", bug_name: "Blank Device" },
    { bug_id: "ios", bug_name: "Crash Invisible iPhone" },
    { bug_id: "infinity", bug_name: "Blank Android 7-16" }
  ],
    
  DDOS: [
    { ddos_id: "s-gbps", ddos_name: "SYN High GBPS" },
    { ddos_id: "s-pps", ddos_name: "SYN Traffic Flood" },
    { ddos_id: "a-gbps", ddos_name: "ACK High GBPS" },
    { ddos_id: "a-pps", ddos_name: "ACK Traffic Flood" },
    { ddos_id: "icmp", ddos_name: "ICMP Flood" },
    { ddos_id: "udp", ddos_name: "GUDP ( HIGH RISK )" }

  ],
  // News data
  NEWS: [
    {
      image: "https://files.catbox.moe/xqkxga.jpg",
      title: "APP TREDICT INVICTUS",
      desc: "Stay Enthusiastic About Work No Matter What Happens"
    }
  ],
  // Role cooldowns (in seconds)
  ROLE_COOLDOWNS: {
    member: 300,
    reseller: 240,
    reseller1: 60,
    owner: 0,
    vip: 60,
  },
  // Max quantities by role
  MAX_QUANTITIES: {
    member: 5,
    reseller: 5,
    reseller1: 5,
    owner: 10,
    vip: 10,
  }
};